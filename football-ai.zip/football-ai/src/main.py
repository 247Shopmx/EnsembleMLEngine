from data_loader import load_data
from features import add_features
from model import train
from predict import predict

def main():
    df = load_data()
    df = add_features(df)

    model = train(df)

    print(predict(model, 2, 1))

if __name__ == "__main__":
    main()
