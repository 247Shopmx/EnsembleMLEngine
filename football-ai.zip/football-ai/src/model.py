from xgboost import XGBClassifier
import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss

FEATURES = [
    "home_goals",
    "away_goals",
    "goal_diff",
    "total_goals"
]

def train(df):
    X = df[FEATURES]
    y = df["result"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = XGBClassifier(
        objective="multi:softprob",
        num_class=3,
        n_estimators=300,
        max_depth=5,
        learning_rate=0.05
    )

    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    probs = model.predict_proba(X_test)

    print("Accuracy:", accuracy_score(y_test, preds))
    print("LogLoss:", log_loss(y_test, probs))

    joblib.dump(model, "models/model.pkl")

    return model
