def expected_score(elo_a, elo_b):
    return 1 / (1 + 10 ** ((elo_b - elo_a) / 400))

def update_elo(elo_a, elo_b, result_a, k=20):
    exp_a = expected_score(elo_a, elo_b)

    new_elo_a = elo_a + k * (result_a - exp_a)
    new_elo_b = elo_b + k * ((1 - result_a) - (1 - exp_a))

    return new_elo_a, new_elo_b
