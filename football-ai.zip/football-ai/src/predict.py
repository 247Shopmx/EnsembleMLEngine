import numpy as np

def predict(model, hg, ag):
    x = np.array([[hg, ag, hg - ag, hg + ag]])
    p = model.predict_proba(x)[0]

    return {
        "away_win": float(p[0]),
        "draw": float(p[1]),
        "home_win": float(p[2])
    }
