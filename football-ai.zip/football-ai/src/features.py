def add_features(df):
    df["goal_diff"] = df["home_goals"] - df["away_goals"]
    df["total_goals"] = df["home_goals"] + df["away_goals"]

    df["result"] = df.apply(
        lambda x: 2 if x["home_goals"] > x["away_goals"]
        else 1 if x["home_goals"] == x["away_goals"]
        else 0,
        axis=1
    )
    return df
